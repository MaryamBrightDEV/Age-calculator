console.log("javascript is connected");
 let birthYearInput = document.getElementById("birthyear");
let button = document.getElementById("calculateBtn");
let result = document.getElementById("result");

button.addEventListener("click", function(){
    let birthyear = birthYearInput.value;
    let age = 2026 - birthyear;
    console.log(age);
})